---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: 'enhancement'
assignees: ''

---

<!--
Thank you for suggesting a feature! Before you continue, please make sure that you have

- read the contributing guidelines: https://pandoc.org/CONTRIBUTING.html
- searched the issue tracker for similar issues (including closed issues): https://github.com/jgm/pandoc/issues
- searched the pandoc-discuss mailing list for relevant discussions: https://groups.google.com/forum/#!forum/pandoc-discuss
-->

**Describe your proposed improvement and the problem it solves.**

**Describe alternatives you've considered.**

